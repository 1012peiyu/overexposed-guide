# 過曝世代互動網站（Notion 嵌入版）

這個資料夾可直接上傳到 GitHub Pages。

- 入口檔：`index.html`
- 已修正：移除 `initBar();` 造成的 JS 錯誤
- 使用方式：
  1. 建立 GitHub 公開 repo（例如 `overexposed-guide`）。
  2. 上傳 `index.html`（以及這個 README 可不傳）。
  3. 到 **Settings → Pages**：
     - Source：Deploy from a branch
     - Branch：`main` / 根目錄 `/`
  4. 取得網址後，貼到 Notion 的 `/embed` 區塊。
